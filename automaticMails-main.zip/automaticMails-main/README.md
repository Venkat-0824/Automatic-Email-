# automaticMails


There are two py files 1. automaticMails.py is for the main file where mails will be sent 2. test_email_sending.py file is for test cases.

here password is not your email password it is generated using google setting
below steps are to enable app password in gmail account
go to the google account setting next go to security tab
after that enable 2-step Verification  and make sure to on it.
after in the search bar please enter app password
create a custom name to and click on generate then you can see password as abcd abcd abcd abcd
enter this password in the pswd variable.



If you are using output please check the smtp_server and port number

Added email list from the xlsv file install openpyxl using pip install openpyxl

